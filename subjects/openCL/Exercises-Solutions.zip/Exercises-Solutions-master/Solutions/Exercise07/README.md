Exercise 7 - using private memory
=================================
