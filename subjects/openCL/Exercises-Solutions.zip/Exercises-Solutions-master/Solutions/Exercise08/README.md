Exercise 8 - using local memory
===============================
