Exercise 9 - The Pi program
===========================
